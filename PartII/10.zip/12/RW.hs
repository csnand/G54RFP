module RW where

import Control.Concurrent.STM

newRWController = do
    nrVar <- newTVar 0
    nwVar <- newTVar 0
    return (nrVar,nwVar)

startRead (nrVar,nwVar) = do
    nr <- readTVar nrVar
    nw <- readTVar nwVar
    if nw == 0
        then writeTVar nrVar (nr+1)
        else retry

endRead (nrVar,nwVar) = do
    nr <- readTVar nrVar
    writeTVar nrVar (nr-1)

startWrite (nrVar,nwVar) = do
    nr <- readTVar nrVar
    nw <- readTVar nwVar
    if (nr == 0 && nw == 0)
        then writeTVar nwVar (nw+1)
        else retry

endWrite (nvVar,nwVar) = do
    nw <- readTVar nwVar
    writeTVar nwVar (nw-1)

main = do
  c <- newRWController
  startRead c
  startWrite c
