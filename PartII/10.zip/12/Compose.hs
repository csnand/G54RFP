module Compose where

import Control.Concurrent
import Control.Concurrent.STM
import Buffer

delayedPut buf n =
    do threadDelay (100000*n)
       atomically (put buf n)

getEither buf1 buf2 =
    get buf1 `orElse` get buf2

main =
    do buf1 <- newBuffer
       buf2 <- newBuffer 
       forkIO (delayedPut buf1 10)
       forkIO (delayedPut buf2 11)
       val <- atomically (getEither buf1 buf2)
       putStrLn (show val)