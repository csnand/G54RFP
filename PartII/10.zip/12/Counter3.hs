module Counter3 where

import Control.Exception
import Control.Concurrent
import Control.Concurrent.STM
import Data.Foldable
import Buffer

update :: TVar Int -> STM ()
update counter =
    do v <- readTVar counter
       writeTVar counter $! (v+1)

loop n counter = forM_ [1..n] (\_ -> atomically (update counter))

main =
    do counter <- newTVarIO 0
       join <- newBuffer
       forkIO ((loop 1000000 counter) `finally` atomically (put join ()))
       loop 1000000 counter
       atomically (get join)
       val <- atomically (readTVar counter)
       putStrLn (show val)
