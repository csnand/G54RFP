module Main where

import Control.Exception
import Control.Concurrent
import Control.Concurrent.STM
import Data.Foldable

update :: TVar Int -> STM ()
update counter =
    do v <- readTVar counter
       writeTVar counter (v+1)

loop n counter = forM_ [1..n] (\_ -> atomically (update counter))

main =
    do counter <- newTVarIO 0
       join <- newEmptyMVar
       forkOS ((loop 100000000 counter) `finally` putMVar join ())
       loop 100000000 counter
       takeMVar join
       val <- atomically (readTVar counter)
       putStrLn "Done" -- (show val)
