module Buffer where

import Control.Concurrent.STM

type Buffer a = TVar [a]

newBuffer = newTVarIO []

put buffer item =
    do ls <- readTVar buffer
       writeTVar buffer (ls ++ [item])

get buffer =
    do ls <- readTVar buffer
       case ls of
         [] -> retry
         (item:rest) ->
             do  writeTVar buffer rest
                 return item

tryGet :: Buffer a -> STM (Maybe a)
tryGet buffer =
    do item <- get buffer
       return (Just item)
    `orElse`
    return Nothing

main =
    do buf <- newBuffer
       ret1 <- atomically (tryGet buf)
       atomically (put buf 42)
       ret2 <- atomically (tryGet buf)
       putStrLn (show ret1)
       putStrLn (show ret2)
