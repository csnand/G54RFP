module Counter where

import Control.Concurrent.STM

update :: TVar Int -> STM ()
update counter =
    do v <- readTVar counter
       writeTVar counter (v+1)

updateIO :: TVar Int -> IO ()
updateIO counter =
    do putStrLn "Before update"
       atomically (update counter)
       putStrLn "After update"

main =
    do counter <- newTVarIO 42
       updateIO counter
       val <- atomically (readTVar counter)
       putStrLn (show val)
