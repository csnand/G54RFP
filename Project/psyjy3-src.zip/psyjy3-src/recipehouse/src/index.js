import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import RecipeSearch from './RecipeSearch';

ReactDOM.render(<RecipeSearch />, document.getElementById('root'));
